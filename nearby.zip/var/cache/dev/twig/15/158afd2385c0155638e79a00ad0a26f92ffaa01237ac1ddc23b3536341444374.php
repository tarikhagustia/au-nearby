<?php

/* default/index.html.twig */
class __TwigTemplate_5c7d9bd077adbd8ec9584510784f3ca664967081c27a86503496401fe9735d52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
      <div class=\"content\">
        ";
        // line 6
        if ($this->getAttribute(($context["params"] ?? null), "city", array(), "array", true, true)) {
            // line 7
            echo "        <h3 class=\"text-center\">Search Nearby Cities with distance ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["params"] ?? $this->getContext($context, "params")), "distance", array(), "array"), "html", null, true);
            echo " km</h3>
        ";
        } else {
            // line 9
            echo "        <h3 class=\"text-center\">Search Nearby Cities with weather</h3>
        ";
        }
        // line 11
        echo "        <form method=\"get\" action=\"\">
          <div class=\"row\">
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">Select city</label>
                <select class=\"form-control\" name=\"city\">
                  ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["cities"] ?? $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["city"]) {
            // line 18
            echo "                      <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["city"], "id", array()), "html", null, true);
            echo "\" ";
            echo ((($this->getAttribute(($context["params"] ?? null), "city", array(), "array", true, true) && ($this->getAttribute(($context["params"] ?? $this->getContext($context, "params")), "city", array(), "array") == $this->getAttribute($context["city"], "id", array())))) ? ("selected") : (null));
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["city"], "name", array()), "html", null, true);
            echo "</option>
                  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['city'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "                </select>
              </div>
            </div>
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">Input distance (in KM)</label>
                <input type=\"number\" class=\"form-control\" name=\"distance\" placeholder=\"eg. 15\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, (($this->getAttribute(($context["params"] ?? null), "distance", array(), "array", true, true)) ? ($this->getAttribute(($context["params"] ?? $this->getContext($context, "params")), "distance", array(), "array")) : (null)), "html", null, true);
        echo "\">
              </div>
            </div>
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">&nbsp;</label>
                <!-- <input type=\"number\" class=\"form-control\" name=\"distance\" placeholder=\"eg. 15\"> -->
                <div>
                  <button class=\"btn btn-primary\" type=\"submit\">Find cities</button>
                </div>
              </div>
            </div>
          </div>
        </form>
        ";
        // line 40
        if ($this->getAttribute(($context["params"] ?? null), "city", array(), "array", true, true)) {
            // line 41
            echo "

        <div class=\"row\">
          <div class=\"col-sm-12\">

            <div id=\"wsMap\" style=\"height:500px; margin: 0px auto;\"></div>
<br>

            <div class=\"table-responsive\">
              <table class=\"table table-striped table-hover table-bordered\">
                <thead>
                  <tr>
                    <th class=\"text-center\">#</th>
                    <th>Name</th>
                    <th>State</th>
                    <th>Postcode</th>
                  </tr>
                </thead>
                <tbody>
                  ";
            // line 60
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["nearest"] ?? $this->getContext($context, "nearest")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["near"]) {
                // line 61
                echo "                  <tr>
                    <td class=\"text-center\" width=\"5%\"> ";
                // line 62
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo " </td>
                    <td>";
                // line 63
                echo twig_escape_filter($this->env, $this->getAttribute($context["near"], "name", array()), "html", null, true);
                echo "</td>
                    <td>";
                // line 64
                echo twig_escape_filter($this->env, $this->getAttribute($context["near"], "state", array()), "html", null, true);
                echo "</td>
                    <td>";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($context["near"], "postcode", array()), "html", null, true);
                echo "</td>
                  </tr>
                  ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['near'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 68
            echo "                </tbody>
              </table>
            </div>
          </div>
        </div>
        ";
        }
        // line 74
        echo "
      </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 79
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 80
        echo "<style>
    .content {
      padding: 10px;
      margin-top: 50px;
      border: 1px solid black;
    }
</style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 88
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 89
        echo "  ";
        if ($this->getAttribute(($context["params"] ?? null), "city", array(), "array", true, true)) {
            // line 90
            echo "  <script async defer src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDfDTwbgh1d1FDEWJwizePMcfOOYBvRW-w&callback=initMap\"
    type=\"text/javascript\"></script>
  <script type=\"text/javascript\">

  function initMap(){
      var locations = JSON.parse('";
            // line 95
            echo ($context["json_nearest"] ?? $this->getContext($context, "json_nearest"));
            echo "');
      var latlng = new google.maps.LatLng(";
            // line 96
            echo twig_escape_filter($this->env, $this->getAttribute(($context["selectedCity"] ?? $this->getContext($context, "selectedCity")), "latitude", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["selectedCity"] ?? $this->getContext($context, "selectedCity")), "longitude", array()), "html", null, true);
            echo ");
      var map = new google.maps.Map(document.getElementById('wsMap'), {
        zoom: 9,
        center: latlng,
      });
      var infowindow = new google.maps.InfoWindow();
      var marker, i;

      console.log(locations.length);

      for (i = 0; i < locations.length; i++) {
          marker = new google.maps.Marker({
              position: new google.maps.LatLng(locations[i]['latitude'], locations[i]['longitude']),
              map: map
          });
          google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              \$.getJSON('/get-weather?city_id='+locations[i]['id'], function(res){
                var info = \"Name: \" + locations[i]['name'] + \"<br>\";
                info += \"Postcode: \" + locations[i]['postcode'] + \"<br>\";
                info += \"State: \" + locations[i]['state'];
                info += \"<br>Temp: \" + res.temp + \" celcius\";
                info += \"<br>humidity: \" + res.humidity;
                info += \"<br>pressure: \" + res.pressure;
                infowindow.setContent(info);
                infowindow.open(map, marker);
              })
          }
          })(marker, i));
      }
  }

  </script>
  ";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  259 => 96,  255 => 95,  248 => 90,  245 => 89,  236 => 88,  219 => 80,  210 => 79,  197 => 74,  189 => 68,  172 => 65,  168 => 64,  164 => 63,  160 => 62,  157 => 61,  140 => 60,  119 => 41,  117 => 40,  100 => 26,  92 => 20,  79 => 18,  75 => 17,  67 => 11,  63 => 9,  57 => 7,  55 => 6,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
      <div class=\"content\">
        {% if params['city'] is defined %}
        <h3 class=\"text-center\">Search Nearby Cities with distance {{params['distance']}} km</h3>
        {% else %}
        <h3 class=\"text-center\">Search Nearby Cities with weather</h3>
        {% endif %}
        <form method=\"get\" action=\"\">
          <div class=\"row\">
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">Select city</label>
                <select class=\"form-control\" name=\"city\">
                  {% for city in cities %}
                      <option value=\"{{ city.id }}\" {{( (params['city'] is defined and params['city'] == city.id) ? \"selected\" : null)}}>{{ city.name }}</option>
                  {% endfor %}
                </select>
              </div>
            </div>
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">Input distance (in KM)</label>
                <input type=\"number\" class=\"form-control\" name=\"distance\" placeholder=\"eg. 15\" value=\"{{params['distance'] is defined ? params['distance'] : null}}\">
              </div>
            </div>
            <div class=\"col-sm-3\">
              <div class=\"form-group\">
                <label class=\"control-label\">&nbsp;</label>
                <!-- <input type=\"number\" class=\"form-control\" name=\"distance\" placeholder=\"eg. 15\"> -->
                <div>
                  <button class=\"btn btn-primary\" type=\"submit\">Find cities</button>
                </div>
              </div>
            </div>
          </div>
        </form>
        {% if params['city'] is defined %}


        <div class=\"row\">
          <div class=\"col-sm-12\">

            <div id=\"wsMap\" style=\"height:500px; margin: 0px auto;\"></div>
<br>

            <div class=\"table-responsive\">
              <table class=\"table table-striped table-hover table-bordered\">
                <thead>
                  <tr>
                    <th class=\"text-center\">#</th>
                    <th>Name</th>
                    <th>State</th>
                    <th>Postcode</th>
                  </tr>
                </thead>
                <tbody>
                  {% for near in nearest %}
                  <tr>
                    <td class=\"text-center\" width=\"5%\"> {{ loop.index }} </td>
                    <td>{{near.name}}</td>
                    <td>{{near.state}}</td>
                    <td>{{near.postcode}}</td>
                  </tr>
                  {% endfor %}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {% endif %}

      </div>
    </div>
{% endblock %}

{% block stylesheets %}
<style>
    .content {
      padding: 10px;
      margin-top: 50px;
      border: 1px solid black;
    }
</style>
{% endblock %}
{% block javascripts %}
  {% if params['city'] is defined %}
  <script async defer src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDfDTwbgh1d1FDEWJwizePMcfOOYBvRW-w&callback=initMap\"
    type=\"text/javascript\"></script>
  <script type=\"text/javascript\">

  function initMap(){
      var locations = JSON.parse('{{ json_nearest | raw}}');
      var latlng = new google.maps.LatLng({{selectedCity.latitude}}, {{selectedCity.longitude}});
      var map = new google.maps.Map(document.getElementById('wsMap'), {
        zoom: 9,
        center: latlng,
      });
      var infowindow = new google.maps.InfoWindow();
      var marker, i;

      console.log(locations.length);

      for (i = 0; i < locations.length; i++) {
          marker = new google.maps.Marker({
              position: new google.maps.LatLng(locations[i]['latitude'], locations[i]['longitude']),
              map: map
          });
          google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              \$.getJSON('/get-weather?city_id='+locations[i]['id'], function(res){
                var info = \"Name: \" + locations[i]['name'] + \"<br>\";
                info += \"Postcode: \" + locations[i]['postcode'] + \"<br>\";
                info += \"State: \" + locations[i]['state'];
                info += \"<br>Temp: \" + res.temp + \" celcius\";
                info += \"<br>humidity: \" + res.humidity;
                info += \"<br>pressure: \" + res.pressure;
                infowindow.setContent(info);
                infowindow.open(map, marker);
              })
          }
          })(marker, i));
      }
  }

  </script>
  {% endif %}
{% endblock %}
", "default/index.html.twig", "/home/tarikhagustia/www/nearby/app/Resources/views/default/index.html.twig");
    }
}
